#version 150
#define MINECRAFT_LIGHT_POWER   (0.6)
#define MINECRAFT_AMBIENT_LIGHT (0.4)
vec4 minecraft_mix_light(vec3 lightDir0,vec3 lightDir1,vec3 normal,vec4 color){return color;} vec4 minecraft_sample_lightmap(sampler2D lightMap,ivec2 uv){return vec4(1.0);} 
