void flw_shaderLight() {
    flw_material.useLight = false;
    flw_material.cardinalLightingMode = 0u;
    flw_material.ambientOcclusion = false;
}
