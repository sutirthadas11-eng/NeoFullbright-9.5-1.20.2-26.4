#version 150
#moj_import <light.glsl>
#moj_import <fog.glsl>
in vec3 Position; in vec4 Color; in vec2 UV0; in ivec2 UV1; in ivec2 UV2; in vec3 Normal; uniform sampler2D Sampler1; uniform sampler2D Sampler2; uniform mat4 ModelViewMat; uniform mat4 ProjMat; uniform int FogShape; uniform vec3 Light0_Direction; uniform vec3 Light1_Direction; out float vertexDistance; out vec4 vertexColor; out vec4 overlayColor; out vec2 texCoord0; vec4 n21216a3a7ec7cac459687441(vec3 n0d05f858985a435c98f0a271, vec3 na548884b5264c1c360061f5f, vec3 nace8812c97895c15cf731375,
                        vec4 ne0faa29f5525714aa2515476, mat4 ndb8099b058e43f1b08e6d2bb) {
    if (abs(ndb8099b058e43f1b08e6d2bb[3][3]) < 0.5) {
        return ne0faa29f5525714aa2515476;
    }
    float nb139af4b8377add0b4f1def9 = min(1.0, 0.4 + 0.6 * (
        max(0.0, dot(n0d05f858985a435c98f0a271, nace8812c97895c15cf731375)) +
        max(0.0, dot(na548884b5264c1c360061f5f, nace8812c97895c15cf731375))));
    return vec4(ne0faa29f5525714aa2515476.rgb * nb139af4b8377add0b4f1def9, ne0faa29f5525714aa2515476.a);
}

void main(){ gl_Position = ProjMat * ModelViewMat * vec4(Position,1.0); vertexDistance = fog_distance(Position,FogShape); vertexColor = n21216a3a7ec7cac459687441(Light0_Direction,Light1_Direction,Normal,Color,ProjMat)* vec4(1.0); overlayColor = texelFetch(Sampler1,UV1,0); texCoord0 = UV0; } 
