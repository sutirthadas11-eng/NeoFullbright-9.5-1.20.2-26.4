#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec4 vertexColor;out vec2 texCoord0;vec4 n62291fcdd89efff1e8aea87a(vec4 ne0faa29f5525714aa2515476){float n41bb6886d93618481eb55c45 = max(ne0faa29f5525714aa2515476.r,max(ne0faa29f5525714aa2515476.g,ne0faa29f5525714aa2515476.b));vec3 nfc0974a06cdb62f2741285ea = n41bb6886d93618481eb55c45 > 0.000001 ? ne0faa29f5525714aa2515476.rgb / n41bb6886d93618481eb55c45 : vec3(1.0);return vec4(nfc0974a06cdb62f2741285ea,ne0faa29f5525714aa2515476.a);}void main(){vec3 pos = Position +(ChunkPosition - CameraBlockPos)+ CameraOffset;gl_Position = ProjMat * ModelViewMat * vec4(pos,1.0);sphericalVertexDistance = fog_spherical_distance(pos);cylindricalVertexDistance = fog_cylindrical_distance(pos);vertexColor = Color* sample_lightmap(Sampler2,UV2);texCoord0 = UV0;} 
