#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
#include <minecraft:chunksection.glsl>
#endif
layout(location = 0)in vec3 Position;layout(location = 1)in vec4 Color;layout(location = 2)in vec2 UV0;layout(location = 3)in ivec2 UV2; 
#ifdef MULTIDRAW_TERRAIN
layout(location = 4)in ivec3 ChunkPosition;layout(location = 5)in float ChunkVisibility; 
#endif
#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler2; 
#endif
layout(location = 0)out float sphericalVertexDistance;layout(location = 1)out float cylindricalVertexDistance;layout(location = 2)out vec4 vertexColor;layout(location = 3)out vec2 texCoord0;layout(location = 4)out float chunkVisibility;vec4 n62291fcdd89efff1e8aea87a(vec4 ne0faa29f5525714aa2515476){float n41bb6886d93618481eb55c45 = max(ne0faa29f5525714aa2515476.r,max(ne0faa29f5525714aa2515476.g,ne0faa29f5525714aa2515476.b));vec3 nfc0974a06cdb62f2741285ea = n41bb6886d93618481eb55c45 > 0.000001 ? ne0faa29f5525714aa2515476.rgb / n41bb6886d93618481eb55c45 : vec3(1.0);return vec4(nfc0974a06cdb62f2741285ea,ne0faa29f5525714aa2515476.a);}void main(){vec3 pos = Position +(ChunkPosition - CameraBlockPos)+ CameraOffset;gl_Position = ProjMat * ModelViewMat * vec4(pos,1.0);sphericalVertexDistance = fog_spherical_distance(pos);cylindricalVertexDistance = fog_cylindrical_distance(pos); 
#ifndef OIT_ALPHA_ONLY
vertexColor = Color* sample_lightmap(Sampler2,UV2); 
#else
vertexColor = Color; 
#endif
texCoord0 = UV0;const float chunkFullyVisibleRange = 16.0;float dist = length(pos);chunkVisibility = mix(1.0,ChunkVisibility,clamp((dist - chunkFullyVisibleRange)/ chunkFullyVisibleRange,0.0,1.0));} 
